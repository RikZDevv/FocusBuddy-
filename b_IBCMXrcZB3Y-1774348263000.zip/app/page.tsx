'use client';

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Drawer, DrawerContent, DrawerTrigger, DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { Copy, Share2, Upload, X, Volume2, VolumeX, MoreVertical, ClipboardPaste, Sparkles, Brain, Mic, FileText, Languages, Network, ImageIcon } from 'lucide-react';

const FOCUS_MODES = ['eli5', 'emoji', 'podcast', 'action_steps'] as const;
const EXTRA_MODES = ['mediscan', 'context_translate', 'mindmap'] as const;
type FocusMode = typeof FOCUS_MODES[number] | typeof EXTRA_MODES[number];

interface FocusResult {
  mode: FocusMode;
  content: string;
  timestamp: Date;
}

const modeConfig = {
  eli5: {
    label: 'ELI5',
    icon: '🧒',
    desc: 'Simple analogies',
    colors: 'from-amber-100 to-orange-100 hover:from-amber-200 hover:to-orange-200',
    ring: 'ring-amber-400',
  },
  emoji: {
    label: '🎨 Visual',
    icon: '✨',
    desc: 'Emoji bullets',
    colors: 'from-emerald-100 to-teal-100 hover:from-emerald-200 hover:to-teal-200',
    ring: 'ring-emerald-400',
  },
  podcast: {
    label: '🎙️ Podcast',
    icon: '🎧',
    desc: 'Conversational',
    colors: 'from-blue-100 to-sky-100 hover:from-blue-200 hover:to-sky-200',
    ring: 'ring-blue-400',
  },
  action_steps: {
    label: '✅ Actions',
    icon: '📋',
    desc: 'ADHD checklist',
    colors: 'from-rose-100 to-pink-100 hover:from-rose-200 hover:to-pink-200',
    ring: 'ring-rose-400',
  },
  mediscan: {
    label: 'MediScan',
    icon: '🩺',
    desc: 'AI Vision OCR',
    colors: 'from-violet-100 to-purple-100 hover:from-violet-200 hover:to-purple-200',
    ring: 'ring-violet-400',
  },
  context_translate: {
    label: 'Context-Translate',
    icon: '🌐',
    desc: 'Smart Glossary',
    colors: 'from-cyan-100 to-blue-100 hover:from-cyan-200 hover:to-blue-200',
    ring: 'ring-cyan-400',
  },
  mindmap: {
    label: 'MindMap',
    icon: '🧠',
    desc: 'Idea Hierarchy',
    colors: 'from-fuchsia-100 to-pink-100 hover:from-fuchsia-200 hover:to-pink-200',
    ring: 'ring-fuchsia-400',
  },
};

export default function FocusBuddy() {
  const [input, setInput] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [activeMode, setActiveMode] = useState<FocusMode>('eli5');
  const [result, setResult] = useState<FocusResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);
  const [isReadingAloud, setIsReadingAloud] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFocus = async (mode: FocusMode) => {
    if (!input.trim() && mode !== 'mediscan') {
      toast.error('⚠️ FocusBuddy needs input to start thinking!');
      return;
    }

    if (mode === 'mediscan' && !image) {
      toast.error('📷 Please upload an image for MediScan!');
      return;
    }

    setActiveMode(mode);
    setIsLoading(true);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('mode', mode);
      formData.append('text', input);
      if (image && mode === 'mediscan') {
        formData.append('image', image);
      }

      const response = await fetch('/api/focus', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'API request failed');
      }

      const data = await response.json();
      setResult({
        mode,
        content: data.result,
        timestamp: new Date(),
      });
      toast.success(`✨ ${modeConfig[mode].label} ready!`);
    } catch (error) {
      console.error('Focus error:', error);
      toast.error(`⚠️ ${error instanceof Error ? error.message : 'Something went wrong. Please try again.'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result.content);
      toast.success('📋 Copied to clipboard!');
    }
  };

  const shareResult = async () => {
    if (result) {
      try {
        await navigator.share({
          title: `FocusBuddy • ${modeConfig[result.mode].label}`,
          text: result.content.slice(0, 200) + '...',
        });
      } catch {
        copyToClipboard();
      }
    }
  };

  const toggleReadAloud = () => {
    if (!result) return;

    if (isReadingAloud) {
      synthRef.current?.cancel();
      setIsReadingAloud(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(result.content);
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      synthRef.current = speechSynthesis;
      speechSynthesis.speak(utterance);
      setIsReadingAloud(true);

      utterance.onend = () => setIsReadingAloud(false);
    }
  };

  const pasteText = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setInput(text);
      toast.success('📋 Text pasted!');
    } catch {
      toast.error('Unable to access clipboard');
    }
  };

  const clearInput = () => {
    setInput('');
    setImage(null);
    setImagePreview(null);
    setResult(null);
    textareaRef.current?.focus();
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      setActiveMode('mediscan');
      toast.success('🩺 Image ready for MediScan!');
    }
  };

  const removeImage = () => {
    setImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-[#FDFBF7] to-[#F5F3EF] p-4 font-sans">
      <div className="max-w-md mx-auto space-y-6 pb-80">
        {/* Header */}
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between pt-2"
        >
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Brain className="h-7 w-7 text-amber-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                FocusBuddy
              </h1>
            </div>
            <p className="text-sm text-slate-600">7 Sages for Neurodiverse Minds</p>
          </div>
          
          <Drawer open={showDrawer} onOpenChange={setShowDrawer} direction="top">
            <DrawerTrigger asChild>
              <Button variant="ghost" size="sm" className="p-2 hover:bg-amber-100">
                <MoreVertical className="h-5 w-5 text-slate-600" />
              </Button>
            </DrawerTrigger>
            <DrawerContent>
              <DrawerHeader className="text-center">
                <DrawerTitle className="text-xl font-bold flex items-center justify-center gap-2">
                  <Sparkles className="h-5 w-5 text-amber-500" />
                  More Tools
                </DrawerTitle>
                <DrawerDescription>Advanced AI-powered features</DrawerDescription>
              </DrawerHeader>
              <div className="p-6 pt-0 space-y-4">
                <div className="grid grid-cols-1 gap-3">
                  {EXTRA_MODES.map((mode) => {
                    const config = modeConfig[mode];
                    return (
                      <Card 
                        key={mode}
                        className={`p-4 cursor-pointer hover:shadow-lg transition-all border-0 bg-gradient-to-br ${config.colors} active:scale-[0.98]`}
                        onClick={() => {
                          if (mode === 'mediscan') {
                            fileInputRef.current?.click();
                          } else {
                            processFocus(mode);
                          }
                          setShowDrawer(false);
                        }}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{config.icon}</span>
                          <div>
                            <div className="font-semibold text-slate-900">{config.label}</div>
                            <p className="text-xs text-slate-600">{config.desc}</p>
                          </div>
                          {mode === 'mediscan' && <ImageIcon className="h-4 w-4 ml-auto text-slate-400" />}
                          {mode === 'context_translate' && <Languages className="h-4 w-4 ml-auto text-slate-400" />}
                          {mode === 'mindmap' && <Network className="h-4 w-4 ml-auto text-slate-400" />}
                        </div>
                      </Card>
                    );
                  })}
                </div>
                
                <div className="pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-center gap-2 text-sm text-slate-600">
                    <span>💡</span>
                    <span className="text-center">Solving cognitive barriers for neurodiverse learners</span>
                  </div>
                </div>
              </div>
            </DrawerContent>
          </Drawer>
        </motion.header>

        {/* Input Area */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-3" 
          aria-label="Input area"
        >
          <div className="relative">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Paste your text, article, or notes here... FocusBuddy will transform it ✨"
              className="min-h-[140px] resize-none p-4 pr-20 text-base border-2 border-slate-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-200 bg-white/80 backdrop-blur-sm shadow-xl rounded-2xl placeholder:text-slate-400"
              disabled={isLoading}
            />
            <div className="absolute top-3 right-3 flex flex-col gap-1">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 hover:bg-amber-100"
                onClick={pasteText}
                title="Paste from clipboard"
              >
                <ClipboardPaste className="h-4 w-4 text-slate-500" />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 hover:bg-red-100"
                onClick={clearInput}
                title="Clear all"
              >
                <X className="h-4 w-4 text-slate-500" />
              </Button>
            </div>
            
            {/* Image Upload */}
            <div className="absolute bottom-3 left-4 flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="sr-only"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 px-3 text-xs hover:bg-violet-100 text-slate-500"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-1" />
                MediScan
              </Button>
            </div>

            {/* Character count */}
            <div className="absolute bottom-3 right-3 text-xs text-slate-400">
              {input.length > 0 && `${input.length} chars`}
            </div>
          </div>

          {/* Image Preview */}
          <AnimatePresence>
            {imagePreview && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="relative"
              >
                <div className="relative rounded-xl overflow-hidden border-2 border-violet-200 bg-violet-50">
                  <img 
                    src={imagePreview} 
                    alt="Upload preview" 
                    className="w-full h-32 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-2 left-3 text-white text-sm font-medium flex items-center gap-1">
                    <FileText className="h-4 w-4" />
                    Ready for MediScan
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 h-7 w-7 p-0 bg-white/90 hover:bg-white rounded-full"
                    onClick={removeImage}
                  >
                    <X className="h-4 w-4 text-slate-600" />
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.section>

        {/* Primary 2x2 Bento Grid */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          aria-label="Primary focus modes" 
          className="grid grid-cols-2 gap-4"
        >
          {FOCUS_MODES.map((mode, index) => {
            const config = modeConfig[mode];
            const isActive = isLoading && activeMode === mode;

            return (
              <motion.div
                key={mode}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 * index }}
              >
                <Card
                  className={`group relative overflow-hidden border-0 shadow-xl bg-gradient-to-br ${config.colors} cursor-pointer hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] ${isActive ? config.ring + ' ring-2' : ''}`}
                  onClick={() => processFocus(mode)}
                >
                  <CardContent className="p-5 h-28 flex flex-col justify-end relative">
                    {isActive ? (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Skeleton className="h-full w-full absolute inset-0 bg-white/50" />
                        <div className="relative z-10 flex flex-col items-center gap-2">
                          <div className="w-8 h-8 border-3 border-amber-200 border-t-amber-500 rounded-full animate-spin" />
                          <span className="text-xs text-slate-600">Processing...</span>
                        </div>
                      </div>
                    ) : (
                      <>
                        <span className="absolute top-3 right-3 text-2xl opacity-50 group-hover:opacity-100 transition-opacity">
                          {config.icon}
                        </span>
                        <div className="font-bold text-lg text-slate-900 mb-1 group-hover:text-slate-800">
                          {config.label}
                        </div>
                        <p className="text-xs text-slate-600 leading-tight">
                          {config.desc}
                        </p>
                      </>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.section>

        {/* MediScan Button (when image is uploaded) */}
        <AnimatePresence>
          {image && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
            >
              <Button
                onClick={() => processFocus('mediscan')}
                disabled={isLoading}
                className="w-full h-14 bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-600 hover:to-purple-600 text-white font-semibold rounded-xl shadow-lg"
              >
                {isLoading && activeMode === 'mediscan' ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Analyzing...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Mic className="h-5 w-5" />
                    Run MediScan on Image
                  </div>
                )}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Results Bottom Sheet */}
      <AnimatePresence>
        {result && (
          <motion.section
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-50"
            aria-label="Results"
          >
            <div className="max-w-md mx-auto px-4 pb-4">
              <Card className="border-0 shadow-2xl rounded-3xl overflow-hidden backdrop-blur-xl bg-white/95">
                <CardContent className="p-0">
                  {/* Header */}
                  <div className="sticky top-0 bg-white/90 backdrop-blur-sm border-b border-slate-100 px-5 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{modeConfig[result.mode].icon}</span>
                      <span className="px-3 py-1 bg-gradient-to-r from-slate-100 to-slate-50 rounded-full text-xs font-semibold text-slate-700">
                        {modeConfig[result.mode].label}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleReadAloud}
                        className={`h-9 w-9 p-0 rounded-full ${isReadingAloud ? 'text-amber-500 bg-amber-50' : 'hover:bg-slate-100'}`}
                        title={isReadingAloud ? 'Stop reading' : 'Read aloud'}
                      >
                        {isReadingAloud ? (
                          <VolumeX className="h-4 w-4" />
                        ) : (
                          <Volume2 className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={copyToClipboard}
                        className="h-9 w-9 p-0 rounded-full hover:bg-slate-100"
                        title="Copy to clipboard"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={shareResult}
                        className="h-9 w-9 p-0 rounded-full hover:bg-slate-100"
                        title="Share"
                      >
                        <Share2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setResult(null)}
                        className="h-9 w-9 p-0 rounded-full hover:bg-red-50 hover:text-red-500"
                        title="Close"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div className="max-h-[50vh] overflow-y-auto p-5">
                    <div className="prose prose-sm max-w-none">
                      <div className="whitespace-pre-wrap text-base leading-relaxed text-slate-800">
                        {result.content}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isLoading && !result && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/10 backdrop-blur-sm z-40 flex items-center justify-center pointer-events-none"
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="bg-white/90 backdrop-blur-xl rounded-2xl p-6 shadow-2xl flex flex-col items-center gap-3"
            >
              <div className="w-12 h-12 border-4 border-amber-200 border-t-amber-500 rounded-full animate-spin" />
              <p className="text-sm font-medium text-slate-600">
                {modeConfig[activeMode].icon} Processing with {modeConfig[activeMode].label}...
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
